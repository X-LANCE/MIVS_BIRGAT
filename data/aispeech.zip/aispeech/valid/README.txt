符合标注格式的数据在 此 文件夹


1. 单领域单意图文件

目前提供的领域有: 地图 天气 打电话 车载控制 音乐
目录:./one_domain_data/xxx.json




2. 单领域多意图文件

车载控制领域，2-4意图
目录:./one_domain_data/车载控制_multi.json




3.跨领域多意图文件

两个单意图的跨领域：
地图_cross_天气 地图_cross_音乐 打电话_cross_音乐 车载控制_cross_天气 车载控制_cross_音乐 地图_cross_打电话 打电话_cross_天气 车载控制_cross_地图 车载控制_cross_打电话 音乐_cross_天气

目录:./cross_data/xxx_cross_xxx.json

车载多意图和其他领域(地图,打电话,天气,音乐)的跨领域:
目录:./cross_data_multi/车载控制_multi_cross_xxx.json



更新日志：
2022/07/24
1.修复英文的pos问题，全部转为char级别的pos
2.增加拼接多意图的意图数量5-10意图，并且加入跨领域数据集中（_multi_5_10）标记
3.车载控制的标注数据更新修复
